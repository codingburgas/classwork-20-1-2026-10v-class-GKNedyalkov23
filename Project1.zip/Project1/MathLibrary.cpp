#include <iostream>
#include "MathLibrary.h"

int calculatePerimeter(int a, int b, int c)
{
	return a + b + c;
}
int calculateArea(int a, int heigth)
{
	return (a * heigth) / 2;
}