#pragma once

int calculatePerimeter(int, int, int);
int calculateArea(int, int);